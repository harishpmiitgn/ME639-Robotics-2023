def jacobian_3r(theta1, theta2, theta3, l1, l2, l3):

    J = np.array([
        [-l1 * np.sin(theta1) - l2 * np.sin(theta1 + theta2) - l3 * np.sin(theta1 + theta2 + theta3),
         -l2 * np.sin(theta1 + theta2) - l3 * np.sin(theta1 + theta2 + theta3),
         -l3 * np.sin(theta1 + theta2 + theta3)],
        [l1 * np.cos(theta1) + l2 * np.cos(theta1 + theta2) + l3 * np.cos(theta1 + theta2 + theta3),
         l2 * np.cos(theta1 + theta2) + l3 * np.cos(theta1 + theta2 + theta3),
         l3 * np.cos(theta1 + theta2 + theta3)]
    ])
    return J


def inverse_kinematics_iterative(x_target, y_target, l1, l2, l3, iterations=1000, learning_rate=0.1):

    # Initialize joint angles
    theta1, theta2, theta3 = 0.0, 0.0, 0.0

    for _ in range(iterations):
        # Current end effector position
        x_current = l1 * np.cos(theta1) + l2 * np.cos(theta1 + theta2) + l3 * np.cos(theta1 + theta2 + theta3)
        y_current = l1 * np.sin(theta1) + l2 * np.sin(theta1 + theta2) + l3 * np.sin(theta1 + theta2 + theta3)

        # Error vector
        error = np.array([x_target - x_current, y_target - y_current])

        # Calculate the Jacobian
        J = jacobian_3r(theta1, theta2, theta3, l1, l2, l3)

        # Update joint angles
        try:
            J_inv = np.linalg.pinv(J)  # Pseudoinverse of Jacobian
            d_theta = J_inv @ error  # Change in joint angles
            theta1 += learning_rate * d_theta[0]
            theta2 += learning_rate * d_theta[1]
            theta3 += learning_rate * d_theta[2]
        except np.linalg.LinAlgError:
            # Jacobian is singular, cannot calculate pseudoinverse
            break

    return theta1, theta2, theta3


# Calculate the inverse kinematics for each point on the circle
theta1_list, theta2_list, theta3_list = [], [], []
for i in range(num_points):
    theta1, theta2, theta3 = inverse_kinematics_iterative(x[i], y[i], l1, l2, l3)
    theta1_list.append(theta1)
    theta2_list.append(theta2)
    theta3_list.append(theta3)

# Plotting the results
plt.figure(figsize=(10, 8))
plt.plot(x, y, label="Desired Circle", color='blue')
for i in range(len(x)):
    # Compute the end effector positions from the joint angles
    x1 = l1 * np.cos(theta1_list[i])
    y1 = l1 * np.sin(theta1_list[i])
    x2 = x1 + l2 * np.cos(theta1_list[i] + theta2_list[i])
    y2 = y1 + l2 * np.sin(theta1_list[i] + theta2_list[i])
    x3 = x2 + l3 * np.cos(theta1_list[i] + theta2_list[i] + theta3_list[i])
    y3 = y2 + l3 * np.sin(theta1_list[i] + theta2_list[i] + theta3_list[i])

    # Plot the manipulator positions
    plt.plot([0, x1, x2, x3], [0, y1, y2, y3], color='gray', alpha=0.5)

plt.xlabel('X-coordinate')
plt.ylabel('Y-coordinate')
plt.title('3R Manipulator Tracing a Circle (Iterative IK)')
plt.legend()
plt.grid
