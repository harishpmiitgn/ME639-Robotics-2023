import numpy as np
import matplotlib.pyplot as plt

# Define the robot configuration
l1, l2, l3 = 0.25, 0.25, 0.25  # Link lengths (in meters)

def inverse_kinematics_puma(x, y, z, l1, l2, l3):

    # Assuming a simple geometric solution for PUMA robot
    theta1 = np.arctan2(y, x)

    # Solving for theta2 and theta3 using cosine law
    r = np.sqrt(x**2 + y**2)
    D = (r**2 + (z - l1)**2 - l2**2 - l3**2) / (2 * l2 * l3)
    theta3 = np.arctan2(np.sqrt(1 - D**2), D)

    phi = np.arctan2(z - l1, r)
    psi = np.arctan2(l3 * np.sin(theta3), l2 + l3 * np.cos(theta3))
    theta2 = phi - psi

    return theta1, theta2, theta3

def forward_kinematics_puma(theta1, theta2, theta3, l1, l2, l3):

    x = (l2*np.cos(theta2) + l3*np.cos(theta2 + theta3)) * np.cos(theta1)
    y = (l2*np.cos(theta2) + l3*np.cos(theta2 + theta3)) * np.sin(theta1)
    z = l1 + l2*np.sin(theta2) + l3*np.sin(theta2 + theta3)

    return x, y, z


def linear_trajectory(start_point, end_point, num_points):

    return np.linspace(start_point, end_point, num_points)

# Define the corner points of the square
A = np.array([0.40, 0.06, 0.1])
B = np.array([0.40, 0.01, 0.1])
C = np.array([0.35, 0.01, 0.1])
D = np.array([0.35, 0.06, 0.1])

# Number of points per side of the square
num_points_per_side = 20

# Generate the trajectory
trajectory = np.concatenate([
    linear_trajectory(A, B, num_points_per_side),
    linear_trajectory(B, C, num_points_per_side),
    linear_trajectory(C, D, num_points_per_side),
    linear_trajectory(D, A, num_points_per_side)
])

# Compute inverse kinematics for each point on the trajectory
joint_angles = np.array([inverse_kinematics_puma(x, y, z, l1, l2, l3) for x, y, z in trajectory])
# Compute forward kinematics to verify the positions
cartesian_coordinates = np.array([forward_kinematics_puma(theta1, theta2, theta3, l1, l2, l3) for theta1, theta2, theta3 in joint_angles])

# Time array (assuming constant time interval between points)
time = np.linspace(0, len(trajectory), len(trajectory))

# Plotting joint angles and Cartesian coordinates as functions of time
plt.figure(figsize=(15, 10))

# Plotting joint angles
plt.subplot(2, 1, 1)
plt.plot(time, joint_angles[:, 0], label='Theta1')
plt.plot(time, joint_angles[:, 1], label='Theta2')
plt.plot(time, joint_angles[:, 2], label='Theta3')
plt.xlabel('Time')
plt.ylabel('Joint Angles (rad)')
plt.title('Joint Angles over Time')
plt.legend()
plt.grid()

# Plotting Cartesian coordinates
plt.subplot(2, 1, 2)
plt.plot(time, cartesian_coordinates[:, 0], label='X')
plt.plot(time, cartesian_coordinates[:, 1], label='Y')
plt.plot(time, cartesian_coordinates[:, 2], label='Z')
plt.xlabel('Time')
plt.ylabel('Cartesian Coordinates (m)')
plt.title('Cartesian Coordinates over Time')
plt.legend()
plt.grid()

plt.tight_layout()
plt.show()
