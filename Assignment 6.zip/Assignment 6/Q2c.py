import numpy as np
import matplotlib.pyplot as plt

# Constants for simulation
dt = 0.01  # Time step
total_time = 5.0  # Total simulation time
time_steps = int(total_time / dt)

# PID Controller parameters for critically-damped behavior
Kp = 10  # Proportional gain
Ki = 0  # Integral gain (not used in this example)
Kd = 20  # Derivative gain

# Robot dynamics parameters
inertia = 1.0  # Inertia of the joint
damping = 0.1  # Damping coefficient

# Desired trajectory: A simple sine wave
desired_trajectory = np.sin(np.linspace(0, 2*np.pi, time_steps))

# Initialize variables
angle = np.zeros(time_steps)  # Actual angle of the joint
velocity = np.zeros(time_steps)  # Velocity of the joint
torque = np.zeros(time_steps)  # Control input (torque)
error = np.zeros(time_steps)  # Error between desired and actual angle

for t in range(1, time_steps):
    # Calculate current error
    error[t] = desired_trajectory[t] - angle[t-1]

    # PID Control (Feedforward + Feedback)
    torque[t] = (desired_trajectory[t] * Kp) + (Kp * error[t]) + (Kd * (error[t] - error[t-1]) / dt)

    # Adding a small random disturbance to the torque
    disturbance = np.random.normal(0, 0.1)
    torque[t] += disturbance

    # Update the robot's joint state based on dynamics
    # Assuming a simple model: torque = inertia * angular_acceleration + damping * angular_velocity
    angular_acceleration = (torque[t] - damping * velocity[t-1]) / inertia
    velocity[t] = velocity[t-1] + angular_acceleration * dt
    angle[t] = angle[t-1] + velocity[t] * dt

# Plotting the results
plt.figure(figsize=(12, 8))

plt.subplot(2, 1, 1)
plt.plot(np.linspace(0, total_time, time_steps), desired_trajectory, label="Desired Trajectory")
plt.plot(np.linspace(0, total_time, time_steps), angle, label="Actual Angle", linestyle='--')
plt.xlabel("Time (s)")
plt.ylabel("Angle (rad)")
plt.title("Joint Angle Over Time")
plt.legend()
plt.grid()

plt.subplot(2, 1, 2)
plt.plot(np.linspace(0, total_time, time_steps), torque, label="Applied Torque")
plt.xlabel("Time (s)")
plt.ylabel("Torque (Nm)")
plt.title("Control Input (Torque) Over Time")
plt.legend()
plt.grid()

plt.tight_layout()
plt.show()
