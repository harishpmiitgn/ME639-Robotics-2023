#define MOTOR_A_PIN1 14
#define MOTOR_A_PIN2 27
#define MOTOR_B_PIN1 13
#define MOTOR_B_PIN2 12

#define CHANNEL_A 0
#define CHANNEL_B 1
#define PWM_FREQ 5000 // 5kHz
#define PWM_RESOLUTION 8 // 8-bit resolution

void setup() {
  // Setup pins
  Serial.begin(9600);
  pinMode(MOTOR_A_PIN1, OUTPUT);
  pinMode(MOTOR_A_PIN2, OUTPUT);
  pinMode(MOTOR_B_PIN1, OUTPUT);
  pinMode(MOTOR_B_PIN2, OUTPUT);

  // Setup PWM channels
  ledcSetup(CHANNEL_A, PWM_FREQ, PWM_RESOLUTION);
  ledcSetup(CHANNEL_B, PWM_FREQ, PWM_RESOLUTION);

  // Attach the pins to the channels
  ledcAttachPin(MOTOR_A_PIN1, CHANNEL_A);
  ledcAttachPin(MOTOR_B_PIN1, CHANNEL_B);
}

void loop() {
  // Drive Motor A forward at half speed
  digitalWrite(MOTOR_A_PIN2, LOW); // Set direction pin low for forward
  ledcWrite(CHANNEL_A, 150); // 50% duty cycle
// channel A is upper motor

  // Drive Motor B backward at full speed
  digitalWrite(MOTOR_B_PIN2, HIGH); // Set direction pin high for backward
  ledcWrite(CHANNEL_B, 0); // 100% duty cycle

  delay(2000); // Run for 2 seconds

  // Stop both motors
  ledcWrite(CHANNEL_A, 0);
  ledcWrite(CHANNEL_B, 0);

  delay(2000); 
  }// Stop for 2 seconds