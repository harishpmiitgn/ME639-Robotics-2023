#include <Arduino.h>

const int encoder1PinA = 26; // Encoder signal A pin for encoder 1
const int encoder1PinB = 25; // Encoder signal B pin for encoder 1

const int encoder2PinA = 33; // Encoder signal A pin for encoder 2
const int encoder2PinB = 32; // Encoder signal B pin for encoder 2

const int pulsesPerRevolution = 8000; // Assuming 200 PPR

volatile int encoder1Position = 0;
volatile int encoder2Position = 0;

void setup() {
  Serial.begin(9600);

  // Encoder pins
  pinMode(encoder1PinA, INPUT_PULLUP);
  pinMode(encoder1PinB, INPUT_PULLUP);
  pinMode(encoder2PinA, INPUT_PULLUP);
  pinMode(encoder2PinB, INPUT_PULLUP);

  // Attach interrupt handlers for encoder pulses
  attachInterrupt(digitalPinToInterrupt(encoder1PinA), handleEncoder1Interrupt, CHANGE);
  attachInterrupt(digitalPinToInterrupt(encoder2PinA), handleEncoder2Interrupt, CHANGE);
}

void loop() {
  // Convert encoder position to degrees
  float degrees1 = (static_cast<float>(encoder1Position) / pulsesPerRevolution) * 360.0;
  float degrees2 = (static_cast<float>(encoder2Position) / pulsesPerRevolution) * 360.0;

  // Print the current encoder position in degrees
  Serial.print("Encoder Position (Degrees1): ");
  Serial.println(degrees1);

  Serial.print("Encoder Position (Degrees2): ");
  Serial.println(degrees2);

  delay(100); // Delay for readability
}

void handleEncoder1Interrupt() {
  int stateA = digitalRead(encoder1PinA);
  int stateB = digitalRead(encoder1PinB);
  int direction = (stateA == stateB) ? 1 : -1;
  encoder1Position += direction;
}

void handleEncoder2Interrupt() {
  int stateA = digitalRead(encoder2PinA);
  int stateB = digitalRead(encoder2PinB);
  int direction = (stateA == stateB) ? 1 : -1;
  encoder2Position += direction;
}