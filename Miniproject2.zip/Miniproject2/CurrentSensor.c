const int sensorPin = A0; // Pin to which the sensor output is connected
const float sensorVcc = 5.0; // Supply voltage to ACS712
const float sensitivity = 185.0; // Sensitivity of the sensor, in mV/A. For ACS712 5A version, it's 185

void setup() {
  Serial.begin(9600);
}

void loop() {
  // Read the analog voltage from the sensor
  int analogValue = analogRead(sensorPin);

  // Convert the analog reading to voltage
  float voltage = (analogValue / 1024.0) * sensorVcc;
  
  // The sensor's output voltage is centered around Vcc/2. Calculate the voltage difference from this center point.
  float voltageDiff = voltage - (sensorVcc / 2);
  
  // Convert the voltage difference to current
  float current = voltageDiff / (sensitivity / 1000.0);
  
  // Print the current value to Serial Monitor
  Serial.print("Current: ");
  Serial.print(current, 3); // Print current with 3 decimal places
  Serial.println(" A");

  delay(1000); // Delay for 1 second
}